/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomGraphics;

/**
 *
 * @author ARYAN TIWARY
 */
import Connections.Dependency;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Toolkit;
import javax.swing.*;
public class graphic {
    
    public static void gradient(Graphics g,JFrame f){
        
        Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
        Paint glass = new GradientPaint(0f,0f,new Color(255,255,255,255),size.width,size.height,new Color(255,255,255,255),true);
    Graphics2D g2d = (Graphics2D)g;
    
    g2d.setPaint(glass);
    g2d.fillRect(0,0,size.height,size.width);
   
    }
    
    public static JPanel gradient2(){
        int R,G,B;
        R=255;
        G=255;
        B=255;
        JPanel panel;
        panel = new javax.swing.JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Paint p = new GradientPaint(0.0f, 0.0f, new Color(R, G, B, 20),getWidth(), getHeight(), new Color(R, G, B, 120), true);
                Graphics2D g2d = (Graphics2D)g;

                g2d.setPaint(p);
                g2d.fillRect(0, 0, getWidth(), getHeight());
                
                
            }        };
         return panel;
    }
    
    
          public static void Gradients(Graphics g,int R,int G, int B, int Alpha){
                Paint p = new GradientPaint(0.0f, 0.0f, new Color(R, G, B, 80),(float)Dependency.width,(float)Dependency.height, new Color(R, G, B, 120), true);
                Graphics2D g2d = (Graphics2D)g;

                g2d.setPaint(p);
                g2d.fillRect(0, 0, (int)Dependency.width, (int)Dependency.height);
          }
                
    protected void paintComponent(Graphics g,int R,int G , int B, int A) {
                Paint p = new GradientPaint(0.0f, 0.0f, new Color(R, G, B, 20),(float)Dependency.width,(float)Dependency.height, new Color(R, G, B, 120), true);
                Graphics2D g2d = (Graphics2D)g;

                g2d.setPaint(p);
                g2d.fillRect(0, 0, (int)Dependency.width, (int)Dependency.height);
                
              }

   
}
