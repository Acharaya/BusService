/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Connections;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import Connections.QueryManager;

/**
 *
 * @author ARYAN TIWARY
 */
public class Connect {
       String url;
    String userName;
    String password;
    String driver;
   static Connection connected;
    
    public Connect(){}
    
   public Connect(String driver,String url,String userName,String password){
        //Activating connection
        this.driver = driver;
        this.url = url;
        this.userName = userName;
        this.password = password;
    
        connect();
    }
    
    public void connect(){
     try{ 
         
         Class.forName(driver);
     
     Connection connection = DriverManager.getConnection(url,userName,password);
   
     connected=connection;
    
    
     }catch(Exception e){
      System.out.println(e);
     }
    }
    
    
}
