/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Connections;

import java.util.ArrayList;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author ARYAN TIWARY
 */
public class Queries extends DataManager{
      static QueryManager query ;
    static String Query1;
    String Query2;
    String Query3;
    String Query4;
    
    public Queries(){
      query  = new QueryManager();
       
        Query1 = "Select id,password,user_name,user_type from admin where id=? AND password=?";
        Query2 = "Insert into availedstatus values(?,?,?,?,?,?)";
        Query3 = "select UID,Availed_status from availedstatus";
           
    }
    
  
    
    public ArrayList<ArrayList<String>> ExecuteFetchBusInfo(){
         return query.FetchBusInfo("select count(id) from busservices", "select * from busservices");   
          
    }
    
    public void ExecuteLogin(String UID,String Password){
          query.FetchIdPassword("Select id,password,user_name,user_type from user where id=? AND password=?", UID, Password);
    }
    
    public void ExecuteUserInfo(){
        
        
    }
    
    
        public void addTableData(JTable table,String [][]Data,String []column){
             
        DefaultTableModel tableModel = new DefaultTableModel(Data,column);

          table.setModel(tableModel);
        }
        
        public void ExecuteAvailedStatus(String UID,Boolean AvailedStatus,String DepartureLocation,String DepartureTime,String ArrivalTime,String DepartureTimeCollege){
                 query.AvailedStatus(Query2,UID,AvailedStatus,DepartureLocation,DepartureTime,ArrivalTime, DepartureTimeCollege);
     
        }
        
        
        public String[] ExecuteCheckAvailedStatus(){
            return query.CheckAvailedStatus(Query3);
        }
        
          
    public ArrayList<ArrayList<String>> ExecuteFetchTableData(String TableName,ArrayList<ArrayList<String>> dataHolder){
         return query.FetchTableData("select count(id) from "+TableName, "select * from "+TableName,dataHolder);   
          
    }
    
       
    
}
