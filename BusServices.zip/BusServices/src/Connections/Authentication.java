/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Connections;
import Connections.*;
import java.sql.*;
import java.util.*;
/**
 *
 * @author ARYAN TIWARY
 */
public class Authentication {

            
    public void Login(String UID,String Password){
       
        Queries loginQuery = new Queries();

     //   login.FetchIdPassword("Select id,password,user_name from user where id=? AND password=?", UID, Password);
        loginQuery.ExecuteLogin(UID,Password);
    }
}
