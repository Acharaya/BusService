/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Connections;
import Views.*;
import java.awt.Dimension;
import java.awt.Toolkit;

/**
 *
 * @author ARYAN TIWARY
 */
public class Dependency {
      
      
    
      public static Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      public static QueryManager mQuery = new QueryManager();
      public static Queries equery =  new Queries();
     
      public static Dashboard d = new Dashboard();
      public static AdminDashboard admin = new AdminDashboard();
         
      public static double height;
     public  static double width;
      
     public Dependency(){
         
          height = screenSize.getHeight();
          width  = screenSize.getWidth();
      }
}
