/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Connections;

import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author ARYAN TIWARY
 */
public class DataManager {
    String UID;
    String Name;
    String UserType;
    String []AvailedStatus=new String[2];
    String Password;
    Boolean isLogged=false;
   
    
    String [][]BusData;
    ArrayList <ArrayList<String>> DashboardData = new ArrayList();
   ArrayList <ArrayList<String>> Bus = new ArrayList<>();
   public static ArrayList <ArrayList<String>> Admin = new ArrayList<>();
   public static ArrayList <ArrayList<String>> AvailStatus = new ArrayList<>();
   public static ArrayList <ArrayList<String>> Drivers = new ArrayList<>();
   public static ArrayList <ArrayList<String>> User = new ArrayList<>();
    
   static HashMap <String,String>loginInfo = new HashMap<String,String>();
    HashMap <String,String>BusInfo = new HashMap<String,String>(); 
   
   DataManager(){
//        System.out.println("Data Manager ");
     
   }
   
   public void setAvailedStatus(String UID,Boolean availedStatus){
    AvailedStatus[0]= UID;
    AvailedStatus[1]=Boolean.toString(availedStatus);
   }
   
   public String[] getAvailedStatus(){
    return AvailedStatus;   
   }
   
    public String[][] getBusData(){
       return BusData;
    }
    
    public void setBusData(String [][]Data){
        BusData=Data;
    }
     public void setUID(String uid){
       
        UID=uid;
    }
    
 
       public void setPassword(String password){
        Password=password;
    }
       
          public void setLogStatus(Boolean islogged){
        isLogged=islogged;
    }
          
    
    public void setloginInfo(String uid,String password,String name,Boolean islogged,String logType){
   
    loginInfo.put("UID",uid);
    loginInfo.put("LogType",logType);
    loginInfo.put("Password",password);
    loginInfo.put("Name",name);
    loginInfo.put("LogStatus",Boolean.toString(islogged));
    
    
    }
    
      public void setBusInfo(String BusID,String BusNumber,String BusDriver,Integer BusPassengers){
   
    loginInfo.put("Bus ID",BusID);
    loginInfo.put("Bus Number",BusNumber);
    loginInfo.put("Bus Driver",BusDriver);
    loginInfo.put("Bus Passengers",Integer.toString(BusPassengers));
    
    }
    
      public void setloginInfo(Boolean islogged){
       
        loginInfo.put("UID",UID);
        loginInfo.put("LogType","user");
        loginInfo.put("Password",Password);
        loginInfo.put("Name",Name);
        loginInfo.put("LogStatus",Boolean.toString(islogged));
         
    }
    
       public String[][] covertList(ArrayList<ArrayList<String>> list){
        String data[][]=new String[2][4];
        
        for(int i=0;i<2;i++){
            for(int j=0;j<4;j++){
                data[i][j] = list.get(i).get(j);
            }
        }
       
        return data;
       }
       
  
       public String[][] covertListD(ArrayList<ArrayList<String>> list,int row,int column){
        String data[][]=new String[row][column];
        
        for(int i=0;i<row;i++){
            for(int j=0;j<column;j++){
                data[i][j] = list.get(i).get(j);
            }
        }
       
        return data;
       }
       
  
      
       
    protected HashMap getloginInfo(){
        return loginInfo;
    }
    

    
}
