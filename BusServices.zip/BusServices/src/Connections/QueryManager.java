/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Connections;
import Connections.Connect;
import Connections.DataManager;
import Connections.Queries;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.time.LocalTime;
import java.util.Date;
import java.sql.Timestamp;
import javax.swing.JOptionPane;
/**
 *
 * @author ARYAN TIWARY
 */
public class QueryManager extends DataManager {
//     String  UID;
//     String Password;
//    static Boolean isLogged=false;
  
  public static HashMap <String,String>loginInfo =new HashMap<>();
  
  public QueryManager(){
      loginInfo = getloginInfo();
      
  }

  
    public void QueryInititate(String query){
       Connect query1 = new Connect();
     
       
       try{
             Statement st=Connect.connected.prepareStatement(query);
             ResultSet resultSet = st.executeQuery(query);
           
             while(resultSet.next()){
          System.out.println(resultSet.getString(2));   }
       }catch(Exception e){
           System.out.println(e);
       }
        
    }
    
       
    public void FetchIdPassword(String query,String id,String password){
     
         int UserAdmin=1;
         
       
       try{
             PreparedStatement st=Connect.connected.prepareStatement(query);
            st.setString(1, id);
             st.setString(2, password);
           ResultSet resultSet = st.executeQuery();
           
           while(UserAdmin!=3){
               
             if(UserAdmin==2){ 
                 
                 st=Connect.connected.prepareStatement(Queries.Query1);
                  st.setString(1, id);
                  st.setString(2, password);
                
                  resultSet = st.executeQuery();
                   while(resultSet.next()){
                
                UID = resultSet.getString(1);
                Password = resultSet.getString(2);
                Name = resultSet.getString(3);
                UserType = resultSet.getString(4);
           
             } 
             }else if(UserAdmin==1){
             
             while(resultSet.next()){
                
                UID = resultSet.getString(1);
                Password = resultSet.getString(2);
                Name = resultSet.getString(3);
                UserType = resultSet.getString(4);
            
             }  }
                UserAdmin++;
           }
          
          
            if(UID.equals(null)){
              System.out.println("Email or password does not exits");
               Connect.connected.close();
            }else{
                 if(UID.equals(id)&&Password.equals(password)){
               
                isLogged=true;
               
                if(!UserType.equals("admin")){
                    UserType="user";
                }
                setloginInfo(UID,Password,Name,isLogged,UserType);
            
            }else{
                isLogged=false;
                 System.out.println(isLogged);
            }
            }
            
               
           
            
       }catch(Exception e){
           System.out.println("Exception QueryManager "+e);
       }
        }
    
    
    
    public void FetchALL(String query,String id,String password){
       
     
       
       try{
             PreparedStatement st=Connect.connected.prepareStatement(query);
            st.setString(1, id);
             st.setString(2, password);
           ResultSet resultSet = st.executeQuery();
           
           
           if(isLogged==true){
                while(resultSet.next()){
                
               String fetchID = resultSet.getString(1);
            String fetchBusNumber = resultSet.getString(2);
            String fetchBusDriver = resultSet.getString(3);
            String fetchPassengers = resultSet.getString(4);
    
            
             }
             
           }else{
               
           }
      }catch(Exception e){
           System.out.println(e);
       }
        
    }
    
    public ArrayList<ArrayList<String>> FetchBusInfo(String countQuery,String query){
        int rows=0;
        String driver="com.mysql.cj.jdbc.Driver";
        String url="jdbc:mysql://localhost:4001/lpu?zeroDateTimeBehavior=CONVERT_TO_NULL";
        String userName="root";
        String password="";

  
       new Connect(driver,url,userName,password);
       
        if(isLogged==false){
           try{
             Statement st=Connect.connected.prepareStatement(query);
             Statement count=Connect.connected.prepareStatement(countQuery);
              ResultSet resultSet = count.executeQuery(countQuery);
              resultSet.next();
              rows=resultSet.getInt(1);
            
              resultSet = st.executeQuery(query);
           //System.out.println("Admin DashBoard : "+rows);
           Bus.add(new ArrayList<String>());
             
                 
                for(int i=0;i<rows;i++){
                 resultSet.next();
                 for(int j=0;j<4;j++){
                     
                  Bus.get(i).add(j,resultSet.getString(j+1));
                 
                 }
                    
              
              
             }
            
       }catch(Exception e){
           System.out.println("Query Manager : "+e);
           
       }
        
        }
       System.out.println(Bus.size());
         return Bus;
    }
    
     public void AvailedStatus(String query,String UID,Boolean AvailedStatus,String DepartureLocation,String DepartureTime,String ArrivalTime,String DepartureTimeCollege){
   
      Date date = new Date();
  
       try{
           
             PreparedStatement st=Connect.connected.prepareStatement(query);
             st.setString(1, UID);
             st.setBoolean(2, AvailedStatus);
             st.setString(3, DepartureLocation);
             st.setTime(4,new Time(date.getTime()));
             st.setTime(5,new Time(date.getTime()) );
             st.setTime(6, new Time(date.getTime()));
            st.executeUpdate();
           
        
       }catch(Exception e){
           System.out.println("Query"+e);
       }
        
    }
    
    
    
     public String[] CheckAvailedStatus(String query){
   
      Date date = new Date();
      String uid=new String();
      Boolean availedStatus=false;
      
  
       try{
           
             Statement st=Connect.connected.prepareStatement(query);
             
             ResultSet rs = st.executeQuery(query);
             while(rs.next()){
                uid= rs.getString(1);
                 availedStatus=rs.getBoolean(2);
    
             }
      setAvailedStatus(uid,availedStatus);
           
        
       }catch(Exception e){
           System.out.println("Query"+e);
       }
         return AvailedStatus;
    }
   
     
     // CRUD OPERATION ADMIN
     
    
    public ArrayList<ArrayList<String>> FetchTableData(String countQuery,String query,ArrayList<ArrayList<String>> dataHolder){
        int rows=0;
        String driver="com.mysql.cj.jdbc.Driver";
        String url="jdbc:mysql://localhost:4001/lpu?zeroDateTimeBehavior=CONVERT_TO_NULL";
        String userName="root";
        String password="";

  
       new Connect(driver,url,userName,password);
       
        if(isLogged==false){
           try{
             Statement st=Connect.connected.prepareStatement(query);
             Statement count=Connect.connected.prepareStatement(countQuery);
              ResultSet resultSet = count.executeQuery(countQuery);
              resultSet.next();
              rows=resultSet.getInt(1);
            
              resultSet = st.executeQuery(query);
           System.out.println("Admin DashBoard : "+rows);
            dataHolder.add(new ArrayList<String>());
             
                 
                for(int i=0;i<rows;i++){
                 resultSet.next();
                 for(int j=0;j<4;j++){
                     
                  dataHolder.get(i).add(j,resultSet.getString(j+1));
                 
                 }
                    
              
              
             }
            
       }catch(Exception e){
           System.out.println("Admin FetchTable Data : "+e);
           
       }
        
        }
       System.out.println(dataHolder.size());
         return dataHolder;
    }
      
     
     
     
     
}
