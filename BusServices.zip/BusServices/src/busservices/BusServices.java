/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package busservices;

import Connections.Connect;

import Connections.QueryManager;
import Connections.Authentication;
import Connections.Queries;
import Connections.Dependency;
import Views.*;

/**
 *
 * @author ARYAN TIWARY
 */
public class BusServices {

    /**
     * @param args the command line arguments
     *
     */
    
      public static Dependency transmit = new Dependency();

    public static void connectionString(){
        
         String driver="com.mysql.cj.jdbc.Driver";
        String url="jdbc:mysql://localhost:4001/lpu?zeroDateTimeBehavior=CONVERT_TO_NULL";
        String userName="root";
        String password="";

  
       new Connect(driver,url,userName,password);
       
        Login login = new Login();
        login.setVisible(true);
      
 
     
    }

   
    public static void main(String[] args) {
       
      connectionString();
    
    }
    
}
